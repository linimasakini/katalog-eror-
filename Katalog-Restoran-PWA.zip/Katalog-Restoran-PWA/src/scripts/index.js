import 'regenerator-runtime';
// css
import '../styles/root.css';
import '../styles/nav.css';
import '../styles/responsive.css';
import '../styles/spinner.css';
import '../styles/header.css';
import '../styles/footer.css';
import '../styles/main.css';
import '../styles/resto-detail.css';
import '../styles/resto-fav.css';

// js
import App from './views/App';
import CONFIG from './global/config';
import swRegister from './utils/sw-register';
import { WebSocketInitiator } from './utils/websocket-initiator';

// component
import './components/navbar';
import './components/hero';
import './components/custom-footer';

// init app
const app = new App({
  button: document.querySelector('.menu'),
  drawer: document.querySelector('.navbar-nav'),
  content: document.querySelector('#main-content'),
});

window.addEventListener('hashchange', () => {
  document.querySelector('.container').scrollIntoView();
  app.renderPage();
});

window.addEventListener('load', () => {
  app.renderPage();
  swRegister();
  WebSocketInitiator.init(CONFIG.WEB_SOCKET_SERVER);
});
