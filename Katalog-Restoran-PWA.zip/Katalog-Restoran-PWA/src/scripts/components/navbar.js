class Navbar extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
        <nav class="navbar">
            <a href="/" class="navbar-logo">Indonesian <span>Resto</span></a>
                <div class="menu">
                    <a href="#" class="menu-lainnya">
                    <i class="fa fa-bars"></i>
                    </a>
                </div>
                  <div class="navbar-nav">
                    <a href="/">
                         Home
                    </a>
                <a href="#/favorite">Favorite</a>
                <a target="_blank" href="https://www.linkedin.com/in/akhmad-nurhadi-7615b5244/" rel="noopener">About Us</a>
            </div>
        </nav>
        `;
  }
}

customElements.define('nav-bar', Navbar);
