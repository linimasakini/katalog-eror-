class CustomFooter extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
        <footer tabindex="0">
        <p class="fot">&copy; Created by Akhmad Nurhadi</p>
        </footer>
      `;
  }
}

customElements.define('custom-footer', CustomFooter);
