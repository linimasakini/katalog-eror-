const CONFIG = {
  BASE_URL: 'https://restaurant-api.dicoding.dev/',
  BASE_IMG_URL: 'https://restaurant-api.dicoding.dev/images/large/',
  KEY: '12345',
  WEB_SOCKET_SERVER: 'wss://javascript.info/article/websocket/chat/ws',
};

export default CONFIG;
